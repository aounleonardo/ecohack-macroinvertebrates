/** Demo data for the prototype. Real app: sites from the NRW 535-site survey table,
 * reaches snapped to OS Open Rivers / OSM waterways, chemistry joined within 90 days and 2 km. */
import type { FeatureCollection, LineString, Point } from 'geojson';
import { statusFor, type Status } from '../map/mapStyle';

export const TODAY = new Date('2026-11-21');

export type Catchment = 'South East Valleys' | 'Gower' | 'Usk';
export type Profile = 'kick' | 'rod' | 'coordinator';
export type Order = 'beetle' | 'mayfly' | 'stonefly' | 'caddis' | 'fly-larva' | 'crustacean' | 'snail' | 'worm' | 'leech';
export type Sensitivity = 'EPT' | 'Sensitive' | 'Tolerant' | null;

export interface Family { slug: string; common: string; latin: string; order: Order; sensitivity: Sensitivity; hasArt: boolean; walesPct?: number }

export const FAMILIES: Record<string, Family> = {
  chironomidae: { slug: 'chironomidae', common: 'Non-biting midges', latin: 'Chironomidae', order: 'fly-larva', sensitivity: 'Tolerant', hasArt: true, walesPct: 97.3 },
  baetidae: { slug: 'baetidae', common: 'Swimming mayflies', latin: 'Baetidae', order: 'mayfly', sensitivity: 'EPT', hasArt: true, walesPct: 96 },
  elmidae: { slug: 'elmidae', common: 'Riffle beetles', latin: 'Elmidae', order: 'beetle', sensitivity: 'Sensitive', hasArt: true, walesPct: 93.2 },
  heptageniidae: { slug: 'heptageniidae', common: 'Flat-headed mayflies', latin: 'Heptageniidae', order: 'mayfly', sensitivity: 'EPT', hasArt: true },
  leuctridae: { slug: 'leuctridae', common: 'Stoneflies', latin: 'Leuctridae', order: 'stonefly', sensitivity: 'EPT', hasArt: true },
  simuliidae: { slug: 'simuliidae', common: 'Blackflies', latin: 'Simuliidae', order: 'fly-larva', sensitivity: null, hasArt: true },
  rhyacophilidae: { slug: 'rhyacophilidae', common: 'Free-living caddis', latin: 'Rhyacophilidae', order: 'caddis', sensitivity: 'EPT', hasArt: true },
  hydropsychidae: { slug: 'hydropsychidae', common: 'Net-spinning caddis', latin: 'Hydropsychidae', order: 'caddis', sensitivity: 'EPT', hasArt: true },
  gammaridae: { slug: 'gammaridae', common: 'Freshwater shrimp', latin: 'Gammaridae', order: 'crustacean', sensitivity: 'Tolerant', hasArt: true },
  dytiscidae: { slug: 'dytiscidae', common: 'Diving beetles', latin: 'Dytiscidae', order: 'beetle', sensitivity: null, hasArt: false, walesPct: 35.5 },
};

export const DEX_ORDER = ['chironomidae', 'baetidae', 'elmidae', 'heptageniidae', 'leuctridae', 'simuliidae', 'rhyacophilidae', 'hydropsychidae', 'gammaridae'];
export const MY_DEX = new Set(['chironomidae', 'baetidae', 'elmidae', 'hydropsychidae', 'gammaridae']); // 5/9 before the Cwmpennar upload

export interface SiteHistory { slug: string; presence: number[]; trend: 'up' | 'flat' | 'down' }
export interface Chemistry { sampled: string; distanceKm: number; bod: number; ammonia: number; doPct: number }
export interface Site {
  id: string; name: string; code?: string; catchment: Catchment;
  lng: number; lat: number; reach: [number, number][];
  lastSampled: string; rodActive?: boolean;
  visits: number; years: string; familiesLast: number;
  expected?: string[];
  history?: SiteHistory[];
  latest?: string[]; latestMore?: number;
  series?: { years: number[]; ept: number[]; taxa: number[]; abundance: number[] };
  chemistry?: Chemistry | null;
}

const reach = (lng: number, lat: number, dLng: number, dLat: number, n = 4): [number, number][] =>
  Array.from({ length: n }, (_, i) => [lng + dLng * i + (i % 2 ? 0.0006 : 0), lat + dLat * i] as [number, number]);

export const SITES: Site[] = [
  {
    id: 'cwmpennar-us', name: 'Cwmpennar (upstream)', catchment: 'South East Valleys',
    lng: -3.3655, lat: 51.6935, reach: reach(-3.3655, 51.6935, -0.0035, -0.0028, 5),
    lastSampled: '2013-09-26', visits: 10, years: '2004–13', familiesLast: 19,
    expected: ['baetidae', 'chironomidae', 'elmidae', 'heptageniidae', 'leuctridae', 'dytiscidae', 'gammaridae'],
  },
  { id: 'aberaman', name: 'Aberaman', catchment: 'South East Valleys', lng: -3.4318, lat: 51.7005, reach: reach(-3.4318, 51.7005, 0.0022, -0.0024), lastSampled: '2026-05-12', visits: 12, years: '2006–26', familiesLast: 21 },
  { id: 'abercwmboi', name: 'Abercwmboi', catchment: 'South East Valleys', lng: -3.4005, lat: 51.6915, reach: reach(-3.4005, 51.6915, 0.0024, -0.0022), lastSampled: '2024-06-03', visits: 8, years: '2008–24', familiesLast: 17 },
  { id: 'aberdare', name: 'Aberdare (Gadlys)', catchment: 'South East Valleys', lng: -3.4502, lat: 51.7155, reach: reach(-3.4502, 51.7155, 0.0025, -0.002), lastSampled: '2019-08-21', visits: 9, years: '2003–19', familiesLast: 15 },
  { id: 'penrhiwceiber', name: 'Penrhiwceiber', catchment: 'South East Valleys', lng: -3.3602, lat: 51.6662, reach: reach(-3.3602, 51.6662, 0.0018, -0.0026), lastSampled: '2026-11-17', rodActive: true, visits: 7, years: '2009–26', familiesLast: 18 },
  {
    id: 'gowerton', name: 'Gowerton', code: 'K2547a726', catchment: 'Gower',
    lng: -4.0398, lat: 51.6455, reach: reach(-4.0398, 51.6455, -0.0012, 0.0028, 5),
    lastSampled: '2026-07-14', visits: 14, years: '2009–26', familiesLast: 24,
    latest: ['baetidae', 'heptageniidae', 'elmidae', 'hydropsychidae', 'rhyacophilidae', 'gammaridae', 'leuctridae', 'chironomidae'], latestMore: 16,
    series: { years: [2009, 2011, 2013, 2015, 2018, 2020, 2022, 2024, 2026], ept: [38, 41, 36, 44, 47, 45, 49, 50, 52], taxa: [18, 20, 19, 21, 22, 22, 23, 23, 24], abundance: [640, 820, 710, 900, 1150, 980, 1240, 1010, 1080] },
    history: [
      { slug: 'baetidae', presence: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1], trend: 'flat' },
      { slug: 'heptageniidae', presence: [0, 1, 0, 1, 1, 0, 1, 1, 1, 1], trend: 'up' },
      { slug: 'elmidae', presence: [1, 1, 1, 1, 1, 0, 1, 1, 1, 1], trend: 'flat' },
      { slug: 'gammaridae', presence: [1, 1, 1, 1, 1, 1, 1, 0, 1, 0], trend: 'down' },
    ],
    chemistry: { sampled: '2026-07-02', distanceKm: 0.6, bod: 1.6, ammonia: 0.04, doPct: 94 },
  },
  { id: 'penclawdd', name: 'Penclawdd', catchment: 'Gower', lng: -4.1012, lat: 51.6398, reach: reach(-4.1012, 51.6398, -0.0004, 0.0026), lastSampled: '2024-04-18', visits: 6, years: '2010–24', familiesLast: 14 },
  { id: 'three-crosses', name: 'Three Crosses', catchment: 'Gower', lng: -4.0668, lat: 51.6218, reach: reach(-4.0668, 51.6218, 0.0006, 0.0025), lastSampled: '2017-09-30', visits: 5, years: '2005–17', familiesLast: 13, chemistry: null },
  { id: 'waunarlwydd', name: 'Waunarlwydd', catchment: 'Gower', lng: -4.0125, lat: 51.6398, reach: reach(-4.0125, 51.6398, -0.0016, 0.0024), lastSampled: '2026-11-18', rodActive: true, visits: 4, years: '2019–26', familiesLast: 16 },
];

export const siteStatus = (s: Site): Status => statusFor(new Date(s.lastSampled), s.rodActive, TODAY);

export function yearsAgoLabel(s: Site): string {
  const days = (TODAY.getTime() - new Date(s.lastSampled).getTime()) / 86400000;
  if (s.rodActive) return `day ${Math.max(1, Math.round(days))} of 7`;
  if (days < 60) return `${Math.round(days / 7)} weeks`;
  if (days < 365) return `${Math.round(days / 30.4)} months`;
  return `${Math.floor(days / 365.25)} years`;
}

export const CATCHMENT_VIEW: Record<Catchment, { center: [number, number]; zoom: number }> = {
  'South East Valleys': { center: [-3.39, 51.69], zoom: 12.2 },
  Gower: { center: [-4.05, 51.64], zoom: 12.4 },
  Usk: { center: [-2.9, 51.7], zoom: 10.5 },
};

export function sitesGeoJSON(catchment: Catchment): FeatureCollection<Point> {
  return {
    type: 'FeatureCollection',
    features: SITES.filter((s) => s.catchment === catchment).map((s) => ({
      type: 'Feature', geometry: { type: 'Point', coordinates: [s.lng, s.lat] },
      properties: { site_id: s.id, name: s.name, status: siteStatus(s) },
    })),
  };
}

export function reachesGeoJSON(catchment: Catchment): FeatureCollection<LineString> {
  return {
    type: 'FeatureCollection',
    features: SITES.filter((s) => s.catchment === catchment).map((s) => ({
      type: 'Feature', geometry: { type: 'LineString', coordinates: s.reach },
      properties: { site_id: s.id, status: siteStatus(s) },
    })),
  };
}

export const fmtDate = (iso: string) => new Date(iso).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
